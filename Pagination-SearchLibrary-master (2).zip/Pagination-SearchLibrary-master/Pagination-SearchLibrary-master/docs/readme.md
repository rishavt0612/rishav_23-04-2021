# Pagination and Search Library

## Introduction
	This library is being used for pagination and for searching data. The library shows data from the database (mock_test_tbl.sql) and shows it in the frontend in a paginated manner. The library is further meant to assist with keyword searches on the data. This allows users to search for a particular record by name, for example.

## Known Issues
	In the search field, we do not get any results if we enter an email address. We need to configure pagination library and search library in such a way that it helps us search using the email address as well.
